-- Manual offline receipt numbers are school-scoped and may be non-sequential.
-- The unique index prevents the same number from being recorded twice.
create unique index if not exists fee_payments_manual_bill_number_unique_idx
  on public.fee_payments (school_id, manual_bill_number)
  where manual_bill_number is not null and btrim(manual_bill_number) <> '';
